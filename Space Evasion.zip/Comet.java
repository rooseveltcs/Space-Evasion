public class Comet extends MovingObject {
}