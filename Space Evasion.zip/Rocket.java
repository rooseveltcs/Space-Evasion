import java.awt.*;

public class Rocket extends MovingObject {
   public Rocket(Point p, int angle) {
      super(p, angle);
   }    
}