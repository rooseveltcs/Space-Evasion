public class Angle {
   private int degrees;
   
   public Angle(int degrees) {
      this.degrees = degrees;
   }
   
   public void setAngle(int deg) {
      degrees = deg;
   }
}